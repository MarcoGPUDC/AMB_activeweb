package app.config;

import org.javalite.activeweb.AbstractDBConfig;
import org.javalite.activeweb.AppContext;

public class DbConfig extends AbstractDBConfig {

    @Override
    public void init(AppContext context) {
        environment("development").jdbc("org.postgresql.Driver", "jdbc:postgresql://localhost:5432/usuarios", "postgres", "0210");
    }
}
