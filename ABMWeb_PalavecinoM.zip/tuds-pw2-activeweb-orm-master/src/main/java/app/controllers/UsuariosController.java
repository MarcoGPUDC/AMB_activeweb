/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.controllers;

import app.models.Usuario;
import java.util.List;
import org.javalite.activejdbc.LazyList;
import org.javalite.activejdbc.Model;
import org.javalite.activeweb.AppController;
import org.javalite.activeweb.annotations.POST;

/**
 *
 * @author marco
 */
public class UsuariosController extends AppController{
    public void listar(){
       List <Usuario> usuarios = Usuario.buscarTodos();
       view("usuarios",usuarios);
    }
    
    public void agregar(){
        
    }
    
    @POST
    public void nuevo() {
        String alias = getHttpServletRequest().getParameter("alias");
        String nombre = getHttpServletRequest().getParameter("nombre");
        String apellido = getHttpServletRequest().getParameter("apellido");
        String contraseña = getHttpServletRequest().getParameter("contrasena");
        String emailPrincipal = getHttpServletRequest().getParameter("email_principal");
        String emailSecundario = getHttpServletRequest().getParameter("email_secundario");
        Integer celular = Integer.valueOf(getHttpServletRequest().getParameter("nro_celular"));
        String tipoUsuario = getHttpServletRequest().getParameter("tipo_de_usuario");
        Usuario u = Usuario.agregar(nombre, apellido, alias, contraseña, emailPrincipal, emailSecundario, celular, tipoUsuario);
        view("usuario_nuevo", u);
    }
    
    @POST
    public void eliminar(){
        Integer id = Integer.parseInt(getHttpServletRequest().getParameter("id"));
        Usuario u = Usuario.findById(id);
        view("usuario_eliminado",u);
        Usuario.delete("id = ?", id);
    }
    
    @POST
    public void modificar(){
        Integer id = Integer.parseInt(getHttpServletRequest().getParameter("id"));
        Usuario u = Usuario.first("id = ?", id);
        view ("usuario_modificar", u);
    }
    
    @POST
    public void modificado(){
        String alias = getHttpServletRequest().getParameter("alias");
        String nombre = getHttpServletRequest().getParameter("nombre");
        String apellido = getHttpServletRequest().getParameter("apellido");
        String contraseña = getHttpServletRequest().getParameter("contrasena");
        String emailPrincipal = getHttpServletRequest().getParameter("email_principal");
        String emailSecundario = getHttpServletRequest().getParameter("email_secundario");
        Integer celular = Integer.valueOf(getHttpServletRequest().getParameter("nro_celular"));
        String tipoUsuario = getHttpServletRequest().getParameter("tipo_de_usuario");
        Usuario u = Usuario.findFirst("alias = ?", alias);
        u.modificar(nombre, apellido, alias, contraseña, emailPrincipal, emailSecundario, celular, tipoUsuario);
        view("nuevo_modificado",u);  
    }
}
