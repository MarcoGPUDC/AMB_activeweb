package app.models;

import java.util.ArrayList;
import org.javalite.activeweb.AppController;

public class CuentaBancaria extends AppController{
    private String CuentaNro;
    private int Saldo;
    private int Descubierto;
    private ArrayList<CuentaBancaria> cuentas = new ArrayList<>();

    public CuentaBancaria() {
    }

    public String getCuentaNro() {
        return CuentaNro;
    }

    public void setCuentaNro(String CuentaNro) {
        this.CuentaNro = CuentaNro;
    }

    public int getSaldo() {
        return Saldo;
    }

    public void setSaldo(int Saldo) {
        this.Saldo = Saldo;
    }

    public int getDescubierto() {
        return Descubierto;
    }

    public void setDescubierto(int Descubierto) {
        this.Descubierto = Descubierto;
    }
    
    public void añadirCuentaBancaria (String numeroCuenta, int saldo){
        CuentaBancaria cuenta = new CuentaBancaria();
        cuenta.setCuentaNro(numeroCuenta);
        cuenta.setSaldo(saldo);
        cuenta.setDescubierto((int) (saldo*0.10));
        cuentas.add(cuenta);
    }
    
    public void inicializar (){
        añadirCuentaBancaria ("00000001", 1000000);
        añadirCuentaBancaria ("00000002", 2000000);
        añadirCuentaBancaria ("00000003", 1500000);
    }
}