/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package app.models;

import java.sql.Date;
import java.time.LocalDate;
import java.util.List;
import org.javalite.activejdbc.Model;
import org.javalite.activejdbc.annotations.Table;

/**
 *
 * @author marco
 */
@Table("public.usuario")
public class Usuario extends Model {
    public static List<Usuario> buscarTodos() {
        List<Usuario> usuario = Usuario
            .findAll();
            
        return usuario;
    }
    
    public static Usuario agregar(String nombre, String apellido, String alias, String contraseña, String emailPrincipal, String emailSecundario, Integer celular, String tipoUsuario) {
        
        Usuario u = new Usuario();
        Date d = Date.valueOf(LocalDate.now());
        
        u.set("alias", alias);
        u.set("apellido", apellido);
        u.set("nombre", nombre);
        u.set("contrasena", contraseña);
        u.set("fecha_alta", d);
        u.set("tipo_de_usuario", tipoUsuario);
        u.set("nro_celular", celular);
        u.set("email_principal", emailPrincipal);
        u.set("email_secundario", emailSecundario);
        
        
        u.saveIt();
        
        return u;
    }
    
    public Usuario modificar(String nombre, String apellido, String alias, String contraseña, String emailPrincipal, String emailSecundario, Integer celular, String tipoUsuario) {
        
        
        this.set("alias", alias);
        this.set("apellido", apellido);
        this.set("nombre", nombre);
        this.set("contrasena", contraseña);
        this.set("tipo_de_usuario", tipoUsuario);
        this.set("nro_celular", celular);
        this.set("email_principal", emailPrincipal);
        this.set("email_secundario", emailSecundario);
        
        
        this.saveIt();
        
        return this;
    }
    
    public static void eliminar(String id){
        Usuario.delete(id, id);
    }
}
